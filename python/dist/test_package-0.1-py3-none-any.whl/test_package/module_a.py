module_var_a = "variable of a module"

def module_a_func():
    print("module a is running")