module_var_b = "variable of b module"

class Module_B:
    def __str__(self):
        return "obj of Module B"